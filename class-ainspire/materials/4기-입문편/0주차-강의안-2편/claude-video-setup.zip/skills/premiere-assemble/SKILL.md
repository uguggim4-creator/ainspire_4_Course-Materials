---
name: premiere-assemble
description: Premiere Pro 시퀀스 자동 조립. 영상 소스 폴더 → 임포트 → 시퀀스 → 줌/패닝 모션 → BGM. 브릿지 필수.
argument-hint: <project_version_path>
disable-model-invocation: true
---

# Premiere Pro 시퀀스 조립

`/product-cf`로 생성한 영상 소스를 Premiere Pro에 임포트하고 시퀀스를 자동 조립한다.

## 전제 조건

- Premiere Pro 실행 중
- CEP 브릿지 패널 활성화 (Window → Extensions → Premiere MCP Bridge)
- 브릿지가 꺼져 있으면 **즉시 중단하고 안내**

## 인자

```
/premiere-assemble <project_version_path>
```

- `$0` — 프로젝트 버전 경로 (예: `E:/Ainspire agent/projects/product-cf/canvas_sneakers/v1_urban_daily`)
- 생략 시 가장 최근 프로젝트의 최신 버전 자동 탐색
- `manifest.json`과 `videos/` 폴더가 존재해야 함

## 브릿지 연결 확인

실행 시 먼저 테스트 명령을 보내서 브릿지 응답을 확인한다:

```javascript
(function(){ return JSON.stringify({alive:true, version:app.version}); })()
```

120초 내 응답 없으면 중단 + "브릿지를 켜주세요" 안내.

---

## 브릿지 통신 규칙 (필수)

| 항목 | 규칙 |
|------|------|
| 임시 디렉토리 | `C:\Users\Slit\AppData\Local\Temp\premiere-mcp-bridge` |
| 명령 파일명 | **`command-{uuid}.json`** (`cmd_` 아님 — CEP는 `command-` 접두사만 감지) |
| 응답 파일명 | `response-{uuid}.json` (CEP 자동 생성) |
| 명령 형식 | `{ "id": uuid, "script": "ExtendScript 코드" }` |
| 경로 | **포워드 슬래시(`/`)만** — 백슬래시는 JSON→evalScript 체인에서 소실됨 |
| Position 좌표 | **0~1 정규화** — 센터 = `[0.5, 0.5]`, ±0.003 ≈ 5px. 픽셀값 사용 금지 |
| 시퀀스 생성 | **`createNewSequenceFromClips()`** 사용 — `createNewSequence()`는 다이얼로그 띄움 |
| 폴링 | 500ms 간격, 최대 120초 타임아웃 |
| 클립 길이 조절 | `clip.end = clip.start.seconds + duration` 으로 트림 (재생 속도 변경 아님) |

---

## 실행 방식

모든 명령은 **하나의 Node.js 스크립트**로 순차 처리한다.

---

## 변수 규칙

스크립트에서 사용하는 변수명:

| 변수 | 값 | 용도 |
|------|------|------|
| `PROJECT_NAME` | `{project}_{concept}` (예: `canvas_sneakers_street_edge`) | 클립 검색, 빈 이름, 시퀀스 이름 |
| `SEQ_NAME` | `{project}_{concept}_v{N}` (예: `canvas_sneakers_street_edge_v2`) | 시퀀스 이름 |

**⚠️ 빈 이름 = `PROJECT_NAME`** — "CF" 같은 접미사를 붙이지 않는다. ProjectTitle을 빈 이름에 쓰지 않는다.

---

## 실행 순서 (8단계 순차 전송)

### 1. 미디어 임포트

- 임포트 전 프로젝트 전체를 스캔하여 이미 같은 이름의 클립이 있는지 확인
- **이미 존재하는 파일은 스킵** — 중복 임포트 방지

```javascript
(function(){
  var root = app.project.rootItem;
  var existing = {};
  function scan(parent) {
    for (var i = 0; i < parent.children.numItems; i++) {
      var item = parent.children[i];
      if (item.type === 1) existing[item.name] = true;
      if (item.children && item.children.numItems > 0) scan(item);
    }
  }
  scan(root);

  var files = [/* manifest.json의 video 파일 전체 경로 — 포워드 슬래시 */];
  var toImport = [];
  for (var i = 0; i < files.length; i++) {
    var fname = files[i].split("/").pop();
    if (!existing[fname]) toImport.push(files[i]);
  }
  if (toImport.length > 0) app.project.importFiles(toImport, true, root, false);
  return JSON.stringify({success:true, imported: toImport.length, skipped: files.length - toImport.length});
})()
```

### 2. 클립 폴더링

- 같은 이름의 빈이 이미 있으면 **재사용** (중복 빈 생성 방지)
- **root 직속 클립만** 이동 (빈 안의 클립은 건드리지 않음)
- **⚠️ 빈 이름 = `PROJECT_NAME`** (`{project}_{concept}`)

```javascript
(function(){
  var root = app.project.rootItem;
  var binName = "{project}_{concept}"; // ⚠️ ProjectTitle 사용 금지, CF 접미사 금지
  var bin = null;
  for (var i = 0; i < root.children.numItems; i++) {
    if (root.children[i].name === binName && root.children[i].type === 2) { bin = root.children[i]; break; }
  }
  if (!bin) bin = root.createBin(binName);

  for (var i = root.children.numItems - 1; i >= 0; i--) {
    var item = root.children[i];
    if (item.name && item.name.indexOf("{project}_{concept}") >= 0 && item.type === 1) item.moveBin(bin);
  }
  return JSON.stringify({success:true});
})()
```

### 3. 시퀀스 생성 + 클립 배치

**중복 제거 + 정렬 규칙:**
- `findClips`로 프로젝트 전체를 재귀 탐색
- **`seen` 객체로 같은 이름의 클립은 첫 번째만 수집** (중복 무시)
- **이름 기준 오름차순 정렬** → s01, s02, ... s15 순서 보장

**⚠️ 클립 배치: 겹침 없이 순차 배치**
- `startTimes[i] = startTimes[i-1] + durations[i-1]` (겹침 0)
- duration 다양성(0.5~5초)이 영상 리듬을 만든다 — 겹침으로 리듬을 만들지 않는다

```javascript
(function(){
  var root = app.project.rootItem;
  var items = [];
  var seen = {};
  function findClips(parent) {
    for (var i = 0; i < parent.children.numItems; i++) {
      var item = parent.children[i];
      if (item.name && item.name.indexOf("{project}_{concept}") >= 0 && item.type === 1) {
        if (!seen[item.name]) { items.push(item); seen[item.name] = true; }
      }
      if (item.children && item.children.numItems > 0) findClips(item);
    }
  }
  findClips(root);
  items.sort(function(a,b){ return a.name < b.name ? -1 : 1; });

  if (items.length === 0) return JSON.stringify({success:false, error:"No clips found"});

  app.project.createNewSequenceFromClips("{SEQ_NAME}", [items[0]]);
  var seq = app.project.activeSequence;
  var vTrack = seq.videoTracks[0];

  // scenario.json의 duration으로 startTimes 계산 (겹침 없이 순차 배치)
  // 예: durations [4,1,4,1,1,3] → startTimes [0, 4, 5, 9, 10, 11]
  var startTimes = [/* 계산된 시작 시간 배열 — 겹침 없음 */];
  for (var i = 1; i < items.length && i < startTimes.length; i++) {
    vTrack.insertClip(items[i], startTimes[i]);
  }
  return JSON.stringify({success:true, placed: items.length, seqName: seq.name});
})()
```

### 4. 시퀀스 폴더링

- 같은 이름의 "Sequences" 빈이 있으면 **재사용**

```javascript
(function(){
  var root = app.project.rootItem;
  var binName = "Sequences";
  var seqBin = null;
  for (var i = 0; i < root.children.numItems; i++) {
    if (root.children[i].name === binName && root.children[i].type === 2) { seqBin = root.children[i]; break; }
  }
  if (!seqBin) seqBin = root.createBin(binName);

  var seqNames = [];
  for (var s = 0; s < app.project.sequences.numSequences; s++)
    seqNames.push(app.project.sequences[s].name);
  for (var i = root.children.numItems - 1; i >= 0; i--) {
    for (var s = 0; s < seqNames.length; s++) {
      if (root.children[i].name === seqNames[s]) { root.children[i].moveBin(seqBin); break; }
    }
  }
  return JSON.stringify({success:true});
})()
```

### 5. 디지털 줌 + 패닝 (Scale + Position 키프레임)

씬 유형별 모션 플랜:

| 유형 | Scale | Position | 의도 |
|------|-------|----------|------|
| Reveal | 100→115% | 센터 고정 | 깊은 push-in |
| Hero | 100→108% | ±0.002 좌우 drift | 느린 접근 |
| Macro | 105→120% | ±0.003 방향별 drift | 디테일 강조 |
| Demo | 112→100% | 센터 고정 | pull-back 임팩트 |
| Lifestyle | 100→105% | ±0.003~0.006 트래킹 | 자연스러운 이동 |
| Highlight | 100→112% | 센터 고정 | 임팩트 줌인 |
| Creative | 108→100% | ±0.004 드리프트 | 초현실 이동 |
| Visual | 100→106% | ±0.002 미세 이동 | 추상적 흐름 |
| Closing | 105→100% | 센터 고정 | 은은한 pull-out |

Macro가 여러 번 등장할 경우 Position drift 방향을 매번 다르게 (4방향 순환).

```javascript
(function(){
  var seq = app.project.activeSequence;
  if (!seq) return JSON.stringify({success:false, error:"No active sequence"});
  var vTrack = seq.videoTracks[0];
  var motions = [/* 씬별 {fromScale, toScale, fromPos, toPos} 배열 */];
  var applied = 0;
  for (var i = 0; i < vTrack.clips.numItems && i < motions.length; i++) {
    var clip = vTrack.clips[i];
    var m = motions[i];
    var comps = clip.components;
    for (var c = 0; c < comps.numItems; c++) {
      if (comps[c].displayName === "Motion") {
        var props = comps[c].properties;
        for (var p = 0; p < props.numItems; p++) {
          if (props[p].displayName === "Scale") {
            props[p].setTimeVarying(true);
            props[p].addKey(clip.start); props[p].setValueAtKey(clip.start, m.fromScale);
            props[p].addKey(clip.end); props[p].setValueAtKey(clip.end, m.toScale);
          }
          if (props[p].displayName === "Position") {
            props[p].setTimeVarying(true);
            props[p].addKey(clip.start); props[p].setValueAtKey(clip.start, m.fromPos);
            props[p].addKey(clip.end); props[p].setValueAtKey(clip.end, m.toPos);
          }
        }
        applied++;
        break;
      }
    }
  }
  return JSON.stringify({success:true, applied: applied});
})()
```

### 6. 클립 트림 (scenario.json duration 기반)

Kling 클립은 모두 5초. scenario.json의 `duration` 값에 맞게 **클립 끝을 잘라서** 길이를 조절한다.
재생 속도는 변경하지 않는다. 5초 중 앞부분 duration만큼만 사용.

**방법: `clip.end` 를 `clip.start + duration`으로 설정**

```javascript
(function(){
  var seq = app.project.activeSequence;
  if (!seq) return JSON.stringify({success:false, error:"No active sequence"});
  var vTrack = seq.videoTracks[0];

  // scenario.json에서 읽은 duration 배열 (0.5~5초 다양)
  var targets = [/* e.g. 4, 1, 4, 1, 1, 3, 1, 3, 1, 2, 1, 2, 1, 3, 5 */];
  var results = [];

  // 뒤에서부터 트림해야 앞 클립의 인덱스가 안 바뀜
  for (var i = vTrack.clips.numItems - 1; i >= 0 && i < targets.length; i--) {
    var clip = vTrack.clips[i];
    var targetDur = targets[i];
    var newEnd = clip.start.seconds + targetDur;

    clip.end = newEnd;
    results.unshift({ scene: i+1, target: targetDur, newEnd: newEnd });
  }

  return JSON.stringify({ success: true, results: results });
})()
```

**주의:**
- **뒤에서부터 트림** — 앞 클립 트림 시 뒤 클립 시작점이 밀릴 수 있으므로 역순 처리
- `clip.end`에 seconds 값을 직접 대입 — Time 객체 또는 Number 둘 다 가능
- 줌/패닝 키프레임(5단계)은 트림 **전에** 적용 (트림 후 키프레임 범위가 줄어듦)

### 7. BGM 생성 + 삽입 (Suno via CometAPI)

시퀀스 조립 후 BGM을 자동 생성하고 오디오 트랙에 배치한다.

#### 7-1. Suno 음악 생성 요청

```bash
# API
URL: https://api.cometapi.com/suno/submit/music
KEY: d:/dev/API_connector/.env → COMET_API_KEY
AUTH: Bearer {COMET_API_KEY}

# Body (Inspiration 모드, 인스트루멘탈)
{
  "gpt_description_prompt": "{프로젝트 컨셉에 맞는 분위기 설명, 30초 내외}",
  "mv": "chirp-crow",
  "make_instrumental": true
}

# 응답: { "code": "success", "data": "{task_id}" }
```

#### 7-2. 폴링 (5초 간격)

```bash
GET https://api.cometapi.com/suno/fetch/{task_id}?_t={timestamp}
```

- 응답에서 clips 배열 추출 (여러 형태 지원: 직접 배열, `data.data`, `data.clips`)
- `clips[0].audio_url` 존재하면 완료
- 2개 클립 생성됨 → 첫 번째 사용

#### 7-3. 오디오 다운로드

- `audio/bgm_{concept}.mp3`로 저장
- Suno URL은 리다이렉트 가능 — 따라가서 다운로드

#### 7-4. Premiere 오디오 임포트 + 배치

```javascript
(function(){
  // 1. 오디오 파일 임포트 (중복 스킵)
  // 2. 시퀀스 찾기 (SEQ_NAME으로)
  // 3. audioTracks[0]에 insertClip(audioItem, 0)
})()
```

#### 7-5. 오디오 트림 + 페이드아웃

```javascript
(function(){
  var seq = app.project.activeSequence;
  var aTrack = seq.audioTracks[0];
  var audioClip = aTrack.clips[0];

  // 오디오 끝을 영상 끝에 맞춤
  var videoEnd = /* scenario.json duration 합계 */;
  audioClip.end = videoEnd;

  // Volume 키프레임: 끝 3초 전부터 페이드아웃
  var comps = audioClip.components;
  for (var c = 0; c < comps.numItems; c++) {
    var props = comps[c].properties;
    for (var p = 0; p < props.numItems; p++) {
      if (props[p].displayName === "Volume") {
        props[p].setTimeVarying(true);
        props[p].addKey(0);
        props[p].setValueAtKey(0, 1.0);
        props[p].addKey(videoEnd - 3);
        props[p].setValueAtKey(videoEnd - 3, 1.0);
        props[p].addKey(videoEnd);
        props[p].setValueAtKey(videoEnd, 0.0);
        break;
      }
    }
  }
  return JSON.stringify({success:true, audioEnd: videoEnd, fadeStart: videoEnd - 3});
})()
```

**BGM 프롬프트 가이드 (제품군별):**

| 제품군 | 프롬프트 키워드 |
|--------|--------------|
| 스니커즈/패션 | dark cinematic electronic beat, urban street vibe, moody bass-heavy |
| 음료 | upbeat energetic pop, refreshing summer vibes, catchy rhythmic |
| 스마트폰/테크 | minimal electronic, futuristic ambient, clean precise beats |
| 럭셔리/패션 | elegant cinematic orchestral, luxury brand film, sophisticated |
| 화장품/뷰티 | soft dreamy pop, airy feminine, gentle piano and synth |
| 자동차 | epic cinematic orchestral, powerful driving beat, dramatic build |

### 참고: QE DOM setSpeed (재생 속도 변경이 필요한 경우)

재생 속도 변경이 필요한 경우(슬로모션/빨리감기)에만 사용:

```
qeClip.setSpeed(speedMultiplier, '00;00;00;00', rippleEdit, maintainAudio, reverse)
```
- 5개 파라미터 필수 (2~4개는 "Not Enough Parameters" 에러)
- speedMultiplier는 Number 타입 필수 (String이면 "Illegal Parameter type")

---

## 완료 후

1. manifest.json status → `"editing"`
2. 결과 요약: 클립 배치 수, 모션 적용 수, 트림 적용 수, BGM 제목
3. **수동 마무리 안내:**
   ```
   시퀀스 조립 완료. 수동 마무리:
   - 트랜지션: 전체 클립 선택 → Ctrl+D (기본 트랜지션 일괄)
   - 색보정: Lumetri Color → LUT 적용
   ```

---

## 핵심 규칙

- **브릿지 없이 실행하지 않는다** — 연결 확인 실패 시 즉시 중단
- **중복 임포트 금지** — 임포트 전 기존 클립 스캔, 같은 이름은 스킵
- **중복 빈 금지** — 빈 생성 전 기존 빈 확인, 있으면 재사용
- **빈 이름 = `{project}_{concept}`** — ProjectTitle 사용 금지, "CF" 접미사 금지
- **클립 수집 시 중복 제거** — `seen` 객체로 같은 이름은 첫 번째만 수집
- **클립 배치: 겹침 없이 순차** — duration 다양성이 리듬을 만든다
- Premiere 경로는 포워드 슬래시만
- Position은 0~1 정규화 (픽셀값 금지)
- 시퀀스는 createNewSequenceFromClips (다이얼로그 금지)
- 명령 파일은 command-{uuid}.json (cmd_ 금지)
- 클립 길이 조절은 `clip.end` 트림 (재생 속도 변경 아님)
- **BGM 페이드아웃: 끝 3초 전부터 Volume 1.0→0.0**
- setSpeed 필요 시: `qeClip.setSpeed(mult, '00;00;00;00', ripple, audio, reverse)` — 5파라미터 필수
